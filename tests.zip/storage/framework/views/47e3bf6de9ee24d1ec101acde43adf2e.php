<?php $__env->startSection('title', 'View Owner Details'); ?>



<?php $__env->startSection('content'); ?>
    <?php if((Auth::check() && Auth::user()->role == 'Admin') || Auth::user()->role == 'BUH'): ?>
        <?php if(session('success')): ?>
            <!-- Trigger the modal with a button (hidden, will be triggered by JavaScript) -->
            <button id="successModalBtn" type="button" class="btn btn-primary" data-toggle="modal" data-target="#successModal"
                style="display: none;">
                Open Modal
            </button>
            <!-- Modal -->
            <div class="modal fade" id="successModal" tabindex="-1" role="dialog" aria-labelledby="successModalLabel"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content rounded-0">
                        <div class="modal-header"
                            style="background: linear-gradient(180deg, rgb(255, 180, 206) 0%, hsla(0, 0%, 100%, 1) 100%);
                        border:none;border-top-left-radius: 0; border-top-right-radius: 0;">
                            <h5 class="modal-title font-educ" id="successModalLabel">Success</h5>
                        </div>
                        <div class="modal-body font-educ text-center">
                            <?php echo e(session('success')); ?>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <link rel="stylesheet" href="<?php echo e(URL::asset('css/contact_detail.css')); ?>">
        <div class="row border-educ rounded mb-3 owner-container">
            <div class="col-md-5 border-right" id="contact-detail">
                <div class="table-title d-flex justify-content-between align-items-center my-3">
                    <h2 class="mt-2 ml-3 headings">Sale Agent Detail</h2>
                    <?php if((Auth::check() && Auth::user()->role == 'BUH') || (Auth::check() && Auth::user()->role == 'Admin')): ?>
                        <a style="padding: 10px 12px;"
                            href="<?php echo e(Auth::user()->role == 'Admin'
                                ? route('admin#update-sale-agent', ['id' => $owner->id])
                                : route('buh#update-sale-agent', ['id' => $owner->id])); ?>"
                            class="btn hover-action mx-1" data-toggle="modal" data-target="#editOwnerModal">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </a>
                        
                    <?php endif; ?>
                </div>
                <div class="row mx-1 mb-1">
                    <div class="col-md-6">
                        <div class="form-group mb-3">
                            <label class="font-educ" for="name">Name</label>
                            <h5 class="fonts text-truncate" id="name"><?php echo e($owner->name); ?></h5>
                        </div>
                        <div class="form-group mb-3">
                            <label class="font-educ" for="email">Email</label>
                            <h5 class="fonts text-truncate" id="email"><?php echo e($owner->email); ?></h5>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group mb-3">
                            <label class="font-educ" for="business-unit">Business Unit</label>
                            <h5 class="fonts text-truncate" id="business-unit"><?php echo e($owner->business_unit); ?></h5>
                        </div>
                        <div class="form-group mb-3">
                            <label class="font-educ" for="country">Country</label>
                            <h5 class="fonts text-truncate" id="country"><?php echo e($owner->nationality); ?></h5>
                        </div>

                    </div>
                </div>
                <div class="row mx-1 mb-1">
                    <div class="col-md-6">

                        <div class="form-group mb-3">
                            <label class="font-educ" for="hubspot-id">Hubspot Id</label>
                            <h5 class="fonts" id="hubspot-id"><?php echo e($owner->hubspot_id); ?></h5>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-7 px-3">
                <div class="d-flex justify-content-between align-items-center my-3">
                    <h2 class="mt-2 ml-2 headings">Contact Overview</h2>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="d-flex justify-content-center btn-group mb-3" role="group"
                            aria-label="Sales Engagement Buttons">
                            <button type="button" class="btn hover-action activity-button active mx-2 rounded"
                                onclick="showSection('totalContactsSection')">
                                Total Interested Contacts
                            </button>
                            <button type="button" class="btn hover-action activity-button mx-2 rounded"
                                onclick="showSection('hubspotContactsSection')">
                                Total HubSpot Contacts
                            </button>
                            <button type="button" class="btn hover-action activity-button mx-2 rounded"
                                onclick="showSection('engagingContactsSection')">
                                Current Engaging Contacts
                            </button>
                        </div>
                    </div>
                </div>
                <div class="row pt-2">
                    <div class="col-12">
                        <!-- Section for Total Contacts Allocated -->
                        <div id="totalContactsSection" class="text-center py-3 section-content">
                            <span class="d-block font-educ"
                                style="font-size: 2rem; font-weight: 500;"><?php echo e($totalContacts); ?></span>
                            <h3 class="font-educ" style="font-size: 2.5rem; font-weight:450;">Total Intrested Contacts</h3>
                        </div>
                        <!-- Section for Total Sync HubSpot Contact -->
                        <div id="hubspotContactsSection" class="text-center py-3 section-content" style="display: none;">
                            <span class="d-block font-educ"
                                style="font-size: 2rem; font-weight: 500;"><?php echo e($hubspotContactsCount); ?></span>
                            <h3 class="font-educ" style="font-size: 2.5rem; font-weight:450;">Total HubSpot Contacts</h3>
                        </div>
                        <!-- Section for Current Engaging Contact -->
                        <div id="engagingContactsSection" class="text-center py-3 section-content" style="display: none;">
                            <span class="d-block font-educ"
                                style="font-size: 2rem; font-weight: 500;"><?php echo e($hubspotCurrentEngagingContact); ?></span>
                            <h3 class="font-educ" style="font-size: 2.5rem; font-weight:450;">Current Engaging Contacts
                            </h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="owner-contacts-container">
            <link rel="stylesheet" href="<?php echo e(URL::asset('css/contact_listing.css')); ?>">
            <div class="table-title d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center">
                    <h5 class="mr-3 my-2 headings">Contact Listing</h5>
                    <button class="btn hover-action mx-3" id="show-contacts">
                        Interested Contacts
                    </button>
                    <button class="archive-table btn mx-3" id="show-archive">
                        Archive Contacts
                    </button>
                    <button class="discard-table btn mx-3" id="show-discard">
                        Discard Contacts
                    </button>
                </div>
                <div class="search-box d-flex align-items-center mr-3 mb-2">
                    <input type="search" class="form-control mr-1" placeholder="Search..." id="search-input"
                        aria-label="Search">
                    <button style="padding: 10px 12px;" class="btn hover-action mx-1" type="submit"
                        data-toggle="tooltip" title="Search">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </button>
                </div>
            </div>
            <div class="table-container" id="contacts">
                <table class="table table-hover mt-2" id="contacts-table">
                    <thead class="text-left font-educ">
                        <tr>
                            <th scope="col">No #</th>
                            <th scope="col" id="name-header">Name
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a" id="sortDown-name"
                                    onclick="sortTable('name', 'asc'); toggleSort('sortDown-name', 'sortUp-name')"></i>
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-up-a-z" id="sortUp-name"
                                    onclick="sortTable('name', 'desc'); toggleSort('sortUp-name', 'sortDown-name')"
                                    style="display: none;"></i>
                            </th>
                            <th scope="col" id="email-header">Email
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a" id="sortDown-email"
                                    onclick="sortTable('email', 'asc'); toggleSort('sortDown-email', 'sortUp-email')"></i>
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-up-a-z" id="sortUp-email"
                                    onclick="sortTable('email', 'desc'); toggleSort('sortUp-email', 'sortDown-email')"
                                    style="display: none;"></i>
                            </th>
                            <th scope="col">Contact
                            </th>
                            <th scope="col">Country
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a" id="sortDown-country"
                                    onclick="sortTable('country', 'asc'); toggleSort('sortDown-country', 'sortUp-country')"></i>
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-up-a-z" id="sortUp-country"
                                    onclick="sortTable('country', 'desc'); toggleSort('sortUp-country', 'sortDown-country')"
                                    style="display: none;"></i>
                            </th>
                            <th class=" position-relative" scope="col">
                                Status
                                <i style="cursor: pointer;" class="fa-solid fa-filter" id="filterIcon"
                                    onclick="toggleFilter()"></i>
                                <!-- Filter Container -->
                                <div id="filterContainer" class="filter-popup container rounded-bottom"
                                    style="display: none;">
                                    <div class="row">
                                        <div class="filter-option">
                                            <input class="ml-3" type="checkbox" id="new" name="status"
                                                value="New" onclick="applyFilter()">
                                            <label for="new" style= "color: #318FFC;">New</label>
                                        </div>
                                        <div class="filter-option">
                                            <input class="ml-3" type="checkbox" id="inProgress" name="status"
                                                value="InProgress" onclick="applyFilter()">
                                            <label for="inProgress" style="color: #FF8300;">In Progress</label>
                                        </div>
                                        <div class="filter-option">
                                            <input class="ml-3" type="checkbox" id="hubspot" name="status"
                                                value="HubSpot Contact" onclick="applyFilter()">
                                            <label for="hubspot" style="color: #FF5C35;">HubSpot</label>
                                        </div>
                                    </div>
                            </th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody class="text-left bg-row fonts">
                        <?php $i = ($ownerContacts->currentPage() - 1) * $ownerContacts->perPage(); ?>
                        <?php $__empty_1 = true; $__currentLoopData = $ownerContacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr data-status="<?php echo e($contact['status']); ?>">
                                <td><?php echo e(++$i); ?></td>
                                <td><?php echo e($contact['name']); ?></td>
                                <td><?php echo e($contact['email']); ?></td>
                                <td>
                                    <?php if(!$contact['contact_number']): ?>
                                        No Contact Number Found.
                                    <?php endif; ?>
                                </td>
                                
                                <?php $countryCodeMapper = app('App\Services\CountryCodeMapper'); ?>

                                <td>
                                    <?php
                                        // Fetch the country code using the injected service
                                        $countryCode = $countryCodeMapper->getCountryCode($contact['country']);
                                    ?>

                                    <?php if($countryCode): ?>
                                        <img src="<?php echo e(asset('flags/' . strtolower($countryCode) . '.svg')); ?>"
                                            alt="<?php echo e($contact['country']); ?>" width="20" height="15">
                                    <?php else: ?>
                                        <!-- Optional: Add a fallback image or text when the country code is not found -->
                                        <span>No flag available</span>
                                    <?php endif; ?>
                                    <?php echo e($contact['country']); ?>

                                </td>
                                <td>
                                    <span class="status-indicator"
                                        style="background-color:
                                    <?php if($contact['status'] === 'HubSpot Contact'): ?> #FFE8E2;color:#FF5C35;
                                    <?php elseif($contact['status'] === 'discard'): ?>
                                        #FF7F86; color: #BD000C;
                                    <?php elseif($contact['status'] === 'InProgress'): ?>
                                        #FFF3CD; color: #FF8300; padding: 5px 10px;
                                    <?php elseif($contact['status'] === 'New'): ?>
                                        #CCE5FF ; color:  #318FFC;
                                    <?php elseif($contact['status'] === 'Archive'): ?>
                                    #E2E3E5; color: #303030; <?php endif; ?>
                                ">
                                        <?php if($contact['status'] === 'HubSpot Contact'): ?>
                                            HubSpot
                                        <?php elseif($contact['status'] === 'discard'): ?>
                                            Discard
                                        <?php elseif($contact['status'] === 'InProgress'): ?>
                                            In Progress
                                        <?php elseif($contact['status'] === 'New'): ?>
                                            New
                                        <?php elseif($contact['status'] === 'Archive'): ?>
                                            Archive
                                        <?php endif; ?>
                                    </span>
                                </td>
                                <td>
                                    <a href=" <?php echo e(Auth::user()->role == 'Admin' ? route('admin#view-contact', ['contact_pid' => $contact->contact_pid]) : route('buh#view-contact', ['contact_pid' => $contact->contact_pid])); ?> "
                                        class="btn hover-action" data-toggle="tooltip" title="View"
                                        style="padding: 10px 12px;">
                                        <i class="fa-solid fa-eye"></i>
                                    </a>
                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center">No contacts found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="table-container" id="archive">
                <table class="table table-hover mt-2" id="archive-table">
                    <thead class="text-left font-educ">
                        <tr class="text-left">
                            <th scope="col">No #</th>
                            <th scope="col">Name <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a"></i></th>
                            <th scope="col">Email <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a"></i></th>
                            <th scope="col">Contact</th>
                            <th scope="col">Country <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a"></i></th>
                            <th scope="col">
                                Status
                                <span class="ml-2" data-bs-toggle="tooltip" data-bs-placement="top"
                                    title="Status of the contact: Active, Discarded, New, In Progress, Archived">
                                    <i class="fa-solid fa-info-circle text-muted"></i>
                                </span>
                            </th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="text-left bg-row">
                        <?php $i = ($ownerArchive->currentPage() - 1) * $ownerArchive->perPage(); ?>
                        <?php $__empty_1 = true; $__currentLoopData = $ownerArchive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td> <?php echo e(++$i); ?> </td>
                                <td> <?php echo e($archive['name']); ?> </td>
                                <td> <?php echo e($archive['email']); ?> </td>
                                <td> <?php echo e($archive['contact_number']); ?> </td>
                                <?php $countryCodeMapper = app('App\Services\CountryCodeMapper'); ?>

                                <td>
                                    <?php
                                        // Fetch the country code using the injected service
                                        $countryCode = $countryCodeMapper->getCountryCode($archive['country']);
                                    ?>

                                    <?php if($countryCode): ?>
                                        <img src="<?php echo e(asset('flags/' . strtolower($countryCode) . '.svg')); ?>"
                                            alt="<?php echo e($archive['country']); ?>" width="20" height="15">
                                    <?php else: ?>
                                        <!-- Optional: Add a fallback image or text when the country code is not found -->
                                        <span>No flag available</span>
                                    <?php endif; ?>
                                    <?php echo e($archive['country']); ?>

                                </td>
                                <td>
                                    <span class="status-indicator"
                                        style="background-color:
                                <?php if($archive['status'] === 'Archive'): ?> #E2E3E5; color: #303030; <?php endif; ?>
                                ">
                                        <?php if($archive['status'] === 'Archive'): ?>
                                            Archive
                                        <?php endif; ?>
                                    </span>
                                </td>
                                <td>
                                    
                                    </a>
                                    <a href=" <?php echo e(Auth::user()->role == 'Admin'
                                        ? route('admin#archive-view', $archive->contact_archive_pid)
                                        : route('archive#view', $archive->contact_archive_pid)); ?> "
                                        class="btn hover-action" data-toggle="tooltip" title="View">
                                        <i class="fa-solid fa-eye " style="font-educ-size: 1.5rem"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center"> No Archive Contacts Found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="table-container" id="discard">
                <table class="table table-hover mt-2" id="discard-table">
                    <thead class="font-educ text-left">
                        <tr class="font-educ text-left">
                            <th scope="col">No #</th>
                            <th scope="col">Name <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a"></i></th>
                            <th scope="col">Email <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a"></i></th>
                            <th scope="col">Contact</th>
                            <th scope="col">Country <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a"></i></th>
                            <th scope="col">
                                Status
                                <span class="ml-2" data-bs-toggle="tooltip" data-bs-placement="top"
                                    title="Status of the contact: Active, Discarded, New, In Progress, Archived">
                                    <i class="fa-solid fa-info-circle text-muted"></i>
                                </span>
                            </th>
                        </tr>
                    </thead>
                    <tbody class="text-left bg-row">
                        <?php $i = ($ownerDiscard->currentPage() - 1) * $ownerDiscard->perPage(); ?>
                        <?php $__empty_1 = true; $__currentLoopData = $ownerDiscard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td> <?php echo e(++$i); ?> </td>
                                <td> <?php echo e($discard['name']); ?> </td>
                                <td> <?php echo e($discard['email']); ?> </td>
                                <td> <?php echo e($discard['contact_number']); ?> </td>
                                <td>
                                    <img src="<?php echo e(asset('flags/' . strtolower($countryCodeMapper->getCountryCode($discard['country'])) . '.svg')); ?>"
                                        alt="<?php echo e($discard['country']); ?>" width="20" height="15">
                                    <?php echo e($discard['country']); ?>

                                </td>
                                <td>
                                    <span class="status-indicator"
                                        style="background-color:
                                    <?php if($discard['status'] === 'Discard'): ?> #FF7F86; color: #BD000C; <?php endif; ?>
                                    ">
                                        <?php if($discard['status'] === 'Discard'): ?>
                                            Discard
                                        <?php endif; ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center">No Discard Contacts Found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div aria-label="Page navigation example " class="paginationContainer">
                <ul class="pagination justify-content-center">
                    <!-- Previous Button -->
                    <li class="page-item <?php echo e($ownerContacts->onFirstPage() ? 'disabled' : ''); ?>">
                        <a class="page-link font-educ" href="<?php echo e($ownerContacts->previousPageUrl()); ?>"
                            aria-label="Previous">&#60;</a>
                    </li>
                    <!-- First Page Button -->
                    <?php if($ownerContacts->currentPage() > 3): ?>
                        <li class="page-item">
                            <a class="page-link font-educ" href="<?php echo e($ownerContacts->url(1)); ?>">1</a>
                        </li>
                        <li class="page-item">
                            <a class="page-link font-educ" href="<?php echo e($ownerContacts->url(2)); ?>">2</a>
                        </li>
                        <li class="page-item disabled">
                            <span class="page-link">...</span>
                        </li>
                    <?php endif; ?>
                    <!-- Middle Page Buttons -->
                    <?php for($i = max($ownerContacts->currentPage() - 1, 1); $i <= min($ownerContacts->currentPage() + 1, $ownerContacts->lastPage()); $i++): ?>
                        <li class="page-item <?php echo e($i == $ownerContacts->currentPage() ? 'active' : ''); ?>">
                            <a class="page-link font-educ <?php echo e($i == $ownerContacts->currentPage() ? 'active-bg' : ''); ?>"
                                href="<?php echo e($ownerContacts->url($i)); ?>"><?php echo e($i); ?></a>
                        </li>
                    <?php endfor; ?>
                    <!-- Last Page Button -->
                    <?php if($ownerContacts->currentPage() < $ownerContacts->lastPage() - 2): ?>
                        <li class="page-item disabled">
                            <span class="page-link">...</span>
                        </li>
                        <li class="page-item">
                            <a class="page-link font-educ"
                                href="<?php echo e($ownerContacts->url($ownerContacts->lastPage() - 1)); ?>"><?php echo e($ownerContacts->lastPage() - 1); ?></a>
                        </li>
                        <li class="page-item">
                            <a class="page-link font-educ"
                                href="<?php echo e($ownerContacts->url($ownerContacts->lastPage())); ?>"><?php echo e($ownerContacts->lastPage()); ?></a>
                        </li>
                    <?php endif; ?>
                    <!-- Next Button -->
                    <li class="page-item <?php echo e(!$ownerContacts->hasMorePages() ? 'disabled' : ''); ?>">
                        <a class="page-link font-educ" href="<?php echo e($ownerContacts->nextPageUrl()); ?>"
                            aria-label="Next">&#62;</a>
                    </li>
                </ul>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-danger text-center mt-5">
            <strong>Access Denied!</strong> You do not have permission to view this page.
        </div>
    <?php endif; ?>
    <script src="<?php echo e(asset('js/show_hide_contacts_table.js')); ?>"></script>
    <script src="<?php echo e(asset('js/active_activity_buttons.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sort.js')); ?>"></script>
    <script src="<?php echo e(asset('js/active_buttons.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            <?php if(session('success')): ?>
                $('#successModal').modal('show');
            <?php endif; ?>
        });
    </script>
    <script>
        function showSection(sectionId) {
            // Hide all sections
            document.querySelectorAll('.section-content').forEach(function(section) {
                section.style.display = 'none';
            });
            // Show the selected section
            document.getElementById(sectionId).style.display = 'block';
        }
    </script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Edit_Owner_Modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CMS\Educlaas\hubspot-cms-project\resources\views/Edit_Owner_Detail_Page.blade.php ENDPATH**/ ?>