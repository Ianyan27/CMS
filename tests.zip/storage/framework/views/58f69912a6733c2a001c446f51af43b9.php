<?php $__env->startSection('title', 'Contact Listing Page'); ?>

<?php $__env->startSection('content'); ?>
    <?php if((Auth::check() && Auth::user()->role == 'Sales_Agent') || Auth::user()->role == 'Admin'): ?>
        <div class="container-max-height">
            <div class="d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center">
                    <h5 class="mr-3 my-2 headings">Contact Listing</h5>
                    <button class="btn hover-action mx-3" id="show-contacts">
                        Interested Contacts
                    </button>
                    <button class="archive-table btn mx-3" id="show-archive">
                        Archive Contacts
                    </button>
                    <button class="discard-table btn mx-3" id="show-discard">
                        Discard Contacts
                    </button>
                </div>
                <div class="search-box d-flex align-items-center mr-3 mb-2">
                    <input type="search" class="form-control mr-1" placeholder="Search Name or Email..." id="search-input"
                        aria-label="Search">
                    <button class="btn hover-action mx-1" type="submit" data-toggle="tooltip" title="Search">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </button>
                </div>
            </div>
            <div class="table-container" id="contacts">
                <table class=" table table-hover mt-2" id="contacts-table">
                    <thead class="text-left font-educ">
                        <tr class="text-left font-educ">
                            <th scope="col">No #</th>
                            <th scope="col" id="name-header">Name
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a" id="sortDown-name"
                                    onclick="sortTable('name', 'asc'); toggleSort('sortDown-name', 'sortUp-name')"></i>
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-up-a-z" id="sortUp-name"
                                    onclick="sortTable('name', 'desc'); toggleSort('sortUp-name', 'sortDown-name')"
                                    style="display: none;"></i>
                            </th>
                            <th scope="col" id="email-header">Email
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a" id="sortDown-email"
                                    onclick="sortTable('email', 'asc'); toggleSort('sortDown-email', 'sortUp-email')"></i>
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-up-a-z" id="sortUp-email"
                                    onclick="sortTable('email', 'desc'); toggleSort('sortUp-email', 'sortDown-email')"
                                    style="display: none;"></i>
                            </th>
                            <th scope="col">Contact
                            </th>
                            <th scope="col">Country
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a" id="sortDown-country"
                                    onclick="sortTable('country', 'asc'); toggleSort('sortDown-country', 'sortUp-country')"></i>
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-up-a-z" id="sortUp-country"
                                    onclick="sortTable('country', 'desc'); toggleSort('sortUp-country', 'sortDown-country')"
                                    style="display: none;"></i>
                            </th>
                            <?php if(Auth::user()->role === 'Admin'): ?>
                                <!-- Display Sales Agent only for Admins -->
                                <th>
                                    Sales Agent
                                </th>
                            <?php endif; ?>
                            <th class=" position-relative" scope="col">
                                Status
                                <i style="cursor: pointer;" class="fa-solid fa-filter" id="filterIcon"
                                    onclick="toggleFilter()"></i>
                                <!-- Filter Container -->
                                <div id="filterContainer" class="filter-popup container rounded-bottom"
                                    style="display: none;">
                                    <div class="row">
                                        <div class="filter-option">
                                            <input class="ml-3" type="checkbox" id="new" name="status"
                                                value="New" onclick="applyFilter()">
                                            <label for="new" style= "color: #318FFC;">New</label>
                                        </div>
                                        <div class="filter-option">
                                            <input class="ml-3" type="checkbox" id="inProgress" name="status"
                                                value="InProgress" onclick="applyFilter()">
                                            <label for="inProgress" style="color: #FF8300;">In Progress</label>
                                        </div>
                                        <div class="filter-option">
                                            <input class="ml-3" type="checkbox" id="hubspot" name="status"
                                                value="HubSpot Contact" onclick="applyFilter()">
                                            <label for="hubspot" style="color: #FF5C35;">HubSpot</label>
                                        </div>
                                    </div>
                                </div>
                            </th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-left bg-row fonts">
                        <?php $i = ($contacts->currentPage() - 1) * $contacts->perPage(); ?>
                        <?php $__empty_1 = true; $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr data-status="<?php echo e($contact['status']); ?>">
                                <td><?php echo e(++$i); ?></td>
                                <td><?php echo e($contact['name']); ?></td>
                                <td><?php echo e($contact['email']); ?></td>
                                <td><?php echo e($contact['contact_number']); ?></td>
                                <?php $countryCodeMapper = app('App\Services\CountryCodeMapper'); ?>
                                <td>
                                    <img src="<?php echo e(asset('flags/' . strtolower($countryCodeMapper->getCountryCode($contact['country'])) . '.svg')); ?>"
                                        alt="<?php echo e($contact['country']); ?>" width="20" height="15">
                                    <?php echo e($contact['country']); ?>

                                </td>
                                <?php if(Auth::user()->role === 'Admin'): ?>
                                    <!-- Display Sales Agent only for Admins -->
                                    <td><?php echo e($contact->owner->owner_name ?? 'Not Assigned'); ?></td>
                                <?php endif; ?>
                                <td>
                                    <span class="status-indicator"
                                        style="background-color:
                                <?php if($contact['status'] === 'HubSpot Contact'): ?> #FFE8E2;color:#FF5C35;
                                <?php elseif($contact['status'] === 'discard'): ?>
                                    #FF7F86; color: #BD000C;
                                <?php elseif($contact['status'] === 'InProgress'): ?>
                                    #FFF3CD; color: #FF8300; padding: 5px 10px;
                                <?php elseif($contact['status'] === 'New'): ?>
                                    #CCE5FF ; color:  #318FFC;
                                <?php elseif($contact['status'] === 'Archive'): ?>
                                #E2E3E5; color: #303030; <?php endif; ?>
                            ">
                                        <?php if($contact['status'] === 'HubSpot Contact'): ?>
                                            HubSpot
                                        <?php elseif($contact['status'] === 'discard'): ?>
                                            Discard
                                        <?php elseif($contact['status'] === 'InProgress'): ?>
                                            In Progress
                                        <?php elseif($contact['status'] === 'New'): ?>
                                            New
                                        <?php elseif($contact['status'] === 'Archive'): ?>
                                            Archive
                                        <?php endif; ?>
                                    </span>
                                </td>
                                <td>
                                    <a href=" <?php echo e(Auth::user()->role == 'Admin' ? route('admin#view-contact', ['contact_pid' => $contact->contact_pid]) : route('contact#view', $contact->contact_pid)); ?> "
                                        class="btn hover-action" data-toggle="tooltip" title="View">
                                        <i class="fa-solid fa-eye"></i>
                                    </a>
                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center">No contacts found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="table-container" id="archive">
                <table class="table table-hover mt-2" id="archive-table">
                    <thead class="text-left font-educ">
                        <tr class="text-left font-educ">
                            <th scope="col">No #</th>
                            <th scope="col">Name <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a"></i></th>
                            <th scope="col">Email <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a"></i></th>
                            <th scope="col">Contact</th>
                            <th scope="col">Country <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a"></i></th>
                            <th scope="col">
                                Status
                                <span class="ml-2" data-bs-toggle="tooltip" data-bs-placement="top"
                                    title="Status of the contact: Active, Discarded, New, In Progress, Archived">
                                    <i class="fa-solid fa-info-circle text-muted"></i>
                                </span>
                            </th>
                            <th scope="col">Action
                            </th>
                        </tr>
                    </thead>
                    <tbody class="text-left bg-row">
                        <?php $i = ($contactArchive->currentPage() - 1) * $contactArchive->perPage(); ?>
                        <?php $__empty_1 = true; $__currentLoopData = $contactArchive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td> <?php echo e(++$i); ?> </td>
                                <td> <?php echo e($archive['name']); ?> </td>
                                <td> <?php echo e($archive['email']); ?> </td>
                                <td> <?php echo e($archive['contact_number']); ?> </td>
                                <td>
                                    <?php $countryCodeMapper = app('App\Services\CountryCodeMapper'); ?>
                                    <?php
                                        // Fetch the country code using the injected service
                                        $countryCode = $countryCodeMapper->getCountryCode($archive['country']);
                                    ?>
                                    <?php if($countryCode): ?>
                                        <img src="<?php echo e(asset('flags/' . strtolower($countryCode) . '.svg')); ?>"
                                            alt="<?php echo e($archive['country']); ?>" width="20" height="15">
                                    <?php else: ?>
                                        <!-- Optional: Add a fallback image or text when the country code is not found -->
                                        <span>No flag available</span>
                                    <?php endif; ?>
                                    <?php echo e($archive['country']); ?>

                                </td>
                                <td>
                                    <span class="status-indicator"
                                        style="background-color:
                            <?php if($archive['status'] === 'Archive'): ?> #E2E3E5; color: #303030; <?php endif; ?>
                            ">
                                        <?php if($archive['status'] === 'Archive'): ?>
                                            Archive
                                        <?php endif; ?>
                                    </span>
                                </td>
                                <td>
                                    <a href=" <?php echo e(Auth::user()->role == 'Admin' ? 
                                    route('admin#archive-view', $archive->contact_archive_pid) :
                                    route('archive#view', $archive->contact_archive_pid)); ?> "
                                        class="btn hover-action" data-toggle="tooltip" title="View">
                                        <i class="fa-solid fa-eye " style="font-educ-size: 1.5rem"></i>
                                    </a>
                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center"> No Archive Contacts</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="table-container" id="discard">
                <table class="table table-hover mt-2" id="discard-table">
                    <thead class="font-educ text-left">
                        <tr class="font-educ text-left">
                            <th scope="col">No #</th>
                            <th scope="col">Name <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a"></i></th>
                            <th scope="col">Email <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a"></i></th>
                            <th scope="col">Contact</th>
                            <th scope="col">Country <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a"></i></th>
                            <th scope="col">
                                Status
                                <span class="ml-2" data-bs-toggle="tooltip" data-bs-placement="top"
                                    title="Status of the contact: Active, Discarded, New, In Progress, Archived">
                                    <i class="fa-solid fa-info-circle text-muted"></i>
                                </span>
                                </td>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-left bg-row">
                        <?php $i = ($contactDiscard->currentPage() - 1) * $contactDiscard->perPage(); ?>
                        <?php $__empty_1 = true; $__currentLoopData = $contactDiscard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td> <?php echo e(++$i); ?> </td>
                                <td> <?php echo e($discard['name']); ?> </td>
                                <td> <?php echo e($discard['email']); ?> </td>
                                <td> <?php echo e($discard['contact_number']); ?> </td>
                                <td>
                                    <img src="<?php echo e(asset('flags/' . strtolower($countryCodeMapper->getCountryCode($discard['country'])) . '.svg')); ?>"
                                        alt="<?php echo e($discard['country']); ?>" width="20" height="15">
                                    <?php echo e($discard['country']); ?>

                                </td>
                                <td>
                                    <span class="status-indicator"
                                        style="background-color:
                            <?php if($discard['status'] === 'Discard'): ?> #FF7F86; color: #BD000C; <?php endif; ?>
                            ">
                                        <?php if($discard['status'] === 'Discard'): ?>
                                            Discard
                                        <?php endif; ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('discard#view', ['contact_discard_pid' => $discard->contact_discard_pid])); ?>"
                                        class="btn hover-action" data-toggle="tooltip" title="View">
                                        <i class="fa-solid fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center">No Discard Contacts</td>
                            </tr>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>
            <div aria-label="Page navigation example " class="paginationContainer">
                <ul class="pagination justify-content-center">
                    <!-- Previous Button -->
                    <li class="page-item <?php echo e($contacts->onFirstPage() ? 'disabled' : ''); ?>">
                        <a class="page-link font-educ" href="<?php echo e($contacts->previousPageUrl()); ?>"
                            aria-label="Previous">&#60;</a>
                    </li>
                    <!-- First Page Button -->
                    <?php if($contacts->currentPage() > 3): ?>
                        <li class="page-item">
                            <a class="page-link font-educ" href="<?php echo e($contacts->url(1)); ?>">1</a>
                        </li>
                        <li class="page-item">
                            <a class="page-link font-educ" href="<?php echo e($contacts->url(2)); ?>">2</a>
                        </li>
                        <li class="page-item disabled">
                            <span class="page-link">...</span>
                        </li>
                    <?php endif; ?>
                    <!-- Middle Page Buttons -->
                    <?php for($i = max($contacts->currentPage() - 1, 1); $i <= min($contacts->currentPage() + 1, $contacts->lastPage()); $i++): ?>
                        <li class="page-item <?php echo e($i == $contacts->currentPage() ? 'active' : ''); ?>">
                            <a class="page-link font-educ <?php echo e($i == $contacts->currentPage() ? 'active-bg' : ''); ?>"
                                href="<?php echo e($contacts->url($i)); ?>"><?php echo e($i); ?></a>
                        </li>
                    <?php endfor; ?>
                    <!-- Last Page Button -->
                    <?php if($contacts->currentPage() < $contacts->lastPage() - 2): ?>
                        <li class="page-item disabled">
                            <span class="page-link">...</span>
                        </li>
                        <li class="page-item">
                            <a class="page-link font-educ"
                                href="<?php echo e($contacts->url($contacts->lastPage() - 1)); ?>"><?php echo e($contacts->lastPage() - 1); ?></a>
                        </li>
                        <li class="page-item">
                            <a class="page-link font-educ"
                                href="<?php echo e($contacts->url($contacts->lastPage())); ?>"><?php echo e($contacts->lastPage()); ?></a>
                        </li>
                    <?php endif; ?>
                    <!-- Next Button -->
                    <li class="page-item <?php echo e(!$contacts->hasMorePages() ? 'disabled' : ''); ?>">
                        <a class="page-link font-educ" href="<?php echo e($contacts->nextPageUrl()); ?>" aria-label="Next">&#62;</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="modal fade" id="successModal" tabindex="-1" role="dialog" aria-labelledby="successModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content rounded-0">
                    <div class="modal-header"
                        style="background: linear-gradient(180deg, rgb(255, 180, 206) 0%, hsla(0, 0%, 100%, 1) 100%);
                        border:none;border-top-left-radius: 0; border-top-right-radius: 0;">
                        <h5 class="modal-title" id="addUserModalLabel" style="color: #91264c;">Success</h5>
                    </div>
                    <div class="modal-body">
                        <?php echo e(session('success')); ?>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-danger text-center mt-5">
            <strong>Access Denied!</strong> You do not have permission to view this page.
        </div>
    <?php endif; ?>
    <script>
        $(document).ready(function() {
            <?php if(session('success')): ?>
                $('#successModal').modal('show');
            <?php endif; ?>
        });
    </script>
    <script src=" <?php echo e(asset('js/show_hide_contacts_table.js')); ?> "></script>
    <script src=" <?php echo e(asset('js/active_buttons.js')); ?> "></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <!-- Add Bootstrap Tooltip Initialization -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CMS\Educlaas\hubspot-cms-project\resources\views/Contact_Listing.blade.php ENDPATH**/ ?>