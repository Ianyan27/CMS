<?php $__env->startSection('title', 'User Listing Page'); ?>


<?php $__env->startSection('content'); ?>
    <?php if(Auth::check() && Auth::user()->role == 'Admin'): ?>
        <script>
            $(document).ready(function() {
                $('#successModal').modal('show');
            });
        </script>
        <?php if(Session::has('success')): ?>
            <!-- Success Modal -->
            <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header"
                            style="background: linear-gradient(180deg, rgb(255, 180, 206) 0%, hsla(0, 0%, 100%, 1) 100%);
                                border:none;border-top-left-radius: 0; border-top-right-radius: 0;">
                            <h5 class="modal-title" id="successModalLabel" style="color: #91264c"><strong>Success</strong>
                            </h5>
                        </div>
                        <div class="modal-body font-educ text-center">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                        <div class="modal-footer" style="border:none;">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal"
                                style="background: #91264c; color:white;">OK</button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
        <!-- Success Modal -->
        <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header"
                        style="background: linear-gradient(180deg, rgb(255, 180, 206) 0%, hsla(0, 0%, 100%, 1) 100%);
                            border:none;border-top-left-radius: 0; border-top-right-radius: 0;">
                        <h5 class="modal-title" id="successModalLabel" style="color: #91264c"><strong>Error</strong>
                        </h5>
                    </div>
                    <div class="modal-body font-educ text-center">
                        <?php echo e(Session::get('error')); ?>

                    </div>
                    <div class="modal-footer" style="border:none;">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"
                            style="background: #91264c; color:white;">OK</button>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <div class="container-max-height">
            <div class="d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center">
                    <h2 class="my-2 mr-3 headings">User Listing Page</h2>
                    <button class="btn hover-action mx-3" type="button" data-toggle="modal" data-target="#addUserModal">
                        <i class="fa-solid fa-square-plus"></i>
                    </button>
                </div>
                <div class="search-box d-flex align-items-center mr-3 mb-2">
                    <input type="search" class="form-control mr-1" placeholder="Search by Email or Name" id="search-input"
                        aria-label="Search">
                    <button class="btn hover-action mx-1" type="submit" data-toggle="tooltip" title="Search">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </button>
                </div>
            </div>
            <div class="table-container">
                <table class="table table-hover mt-2">
                    <thead class="text-left font-educ">
                        <tr>
                            <th scope="col">No #</th>
                            <th scope="col" id="name-header">Name
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a" id="sortDown-name"
                                    onclick="sortTable('name', 'asc'); toggleSort('sortDown-name', 'sortUp-name')"></i>
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-up-a-z" id="sortUp-name"
                                    onclick="sortTable('name', 'desc'); toggleSort('sortUp-name', 'sortDown-name')"
                                    style="display: none;"></i>
                            </th>
                            <th scope="col" id="email-header">Email
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a" id="sortDown-email"
                                    onclick="sortTable('email', 'asc'); toggleSort('sortDown-email', 'sortUp-email')"></i>
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-up-a-z" id="sortUp-email"
                                    onclick="sortTable('email', 'desc'); toggleSort('sortUp-email', 'sortDown-email')"
                                    style="display: none;"></i>
                            </th>
                            <th scope="col" id="role-header">Role
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a" id="sortDown-role"
                                    onclick="sortTable('role', 'asc'); toggleSort('sortDown-role', 'sortUp-role')"></i>
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-up-a-z" id="sortUp-role"
                                    onclick="sortTable('role', 'desc'); toggleSort('sortUp-role', 'sortDown-role')"
                                    style="display: none;"></i>
                            </th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="text-left bg-row fonts">
                        <?php $i = ($userData->currentPage() - 1) * $userData->perPage() + 1; ?>
                        <?php $__empty_1 = true; $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td>
                                    <?php if($user->role == 'Admin'): ?>
                                        Admin
                                    <?php elseif($user->role == 'Sales_Agent'): ?>
                                        Sales Agent
                                    <?php elseif($user->role == 'BUH'): ?>
                                        BUH
                                    <?php elseif($user->role == 'Head'): ?>
                                        Head
                                    <?php elseif($user->role == 'Sales_Admin'): ?>
                                        Sales Admin
                                    <?php elseif($user->role == 'NA'): ?>
                                        Not Assigned
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a class="btn hover-action" data-toggle="modal"
                                        data-target="#editUserModal<?php echo e($user->id); ?>">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </a>
                                    <a class="btn hover-action" data-toggle="modal"
                                        data-target="#deleteUserModal<?php echo e($user->id); ?>">
                                        <i class="fa-solid fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center">No User Found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div aria-label="Page navigation example" class="paginationContainer">
                <ul class="pagination justify-content-center">
                    <!-- Previous Button -->
                    <li class="page-item <?php echo e($userData->onFirstPage() ? 'disabled' : ''); ?>">
                        <a class="page-link font-educ" href="<?php echo e($userData->previousPageUrl()); ?>"
                            aria-label="Previous">&#60;</a>
                    </li>
                    <!-- First Page Button -->
                    <?php if($userData->currentPage() > 3): ?>
                        <li class="page-item">
                            <a class="page-link font-educ" href="<?php echo e($userData->url(1)); ?>">1</a>
                        </li>
                        <li class="page-item">
                            <a class="page-link font-educ" href="<?php echo e($userData->url(2)); ?>">2</a>
                        </li>
                        <li class="page-item disabled">
                            <span class="page-link">...</span>
                        </li>
                    <?php endif; ?>
                    <!-- Middle Page Buttons -->
                    <?php for($i = max($userData->currentPage() - 1, 1); $i <= min($userData->currentPage() + 1, $userData->lastPage()); $i++): ?>
                        <li class="page-item <?php echo e($i == $userData->currentPage() ? 'active' : ''); ?>">
                            <a class="page-link font-educ <?php echo e($i == $userData->currentPage() ? 'active-bg' : ''); ?>"
                                href="<?php echo e($userData->url($i)); ?>"><?php echo e($i); ?></a>
                        </li>
                    <?php endfor; ?>
                    <!-- Last Page Button -->
                    <?php if($userData->currentPage() < $userData->lastPage() - 2): ?>
                        <li class="page-item disabled">
                            <span class="page-link">...</span>
                        </li>
                        <li class="page-item">
                            <a class="page-link font-educ"
                                href="<?php echo e($userData->url($userData->lastPage() - 1)); ?>"><?php echo e($userData->lastPage() - 1); ?></a>
                        </li>
                        <li class="page-item">
                            <a class="page-link font-educ"
                                href="<?php echo e($userData->url($userData->lastPage())); ?>"><?php echo e($userData->lastPage()); ?></a>
                        </li>
                    <?php endif; ?>
                    <!-- Next Button -->
                    <li class="page-item <?php echo e(!$userData->hasMorePages() ? 'disabled' : ''); ?>">
                        <a class="page-link font-educ" href="<?php echo e($userData->nextPageUrl()); ?>" aria-label="Next">&#62;</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- Edit User Modal -->
        <?php $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="editUserModal<?php echo e($user->id); ?>" tabindex="-1"
                aria-labelledby="editUserModalLabel<?php echo e($user->id); ?>" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content rounded-0">
                        <div class="modal-header d-flex justify-content-between align-items-center"
                            style="background: linear-gradient(180deg, rgb(255, 180, 206) 0%, hsla(0, 0%, 100%, 1) 100%);
                        border:none;border-top-left-radius: 0; border-top-right-radius: 0;">
                            <h5 class="modal-title" id="editUserModalLabel<?php echo e($user->id); ?>">
                                <strong style="color: #91264c">Edit User</strong>
                            </h5>
                            <img src="<?php echo e(url('/images/02-EduCLaaS-Logo-Raspberry-300x94.png')); ?>" alt="Company Logo"
                                style="height: 30px;">
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(route('admin#update-user', $user->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <!-- Left Column -->
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="font-educ" for="editName<?php echo e($user->id); ?>">Name</label>
                                            <input type="text" class="form-control fonts"
                                                id="editName<?php echo e($user->id); ?>" name="name"
                                                value="<?php echo e($user->name); ?>" readonly>
                                        </div>
                                        <div class="form-group">
                                            <label class="font-educ" for="editEmail<?php echo e($user->id); ?>">Email</label>
                                            <input type="email" class="form-control fonts"
                                                id="editEmail<?php echo e($user->id); ?>" name="email"
                                                value="<?php echo e($user->email); ?>" readonly>
                                        </div>
                                    </div>
                                    <!-- Right Column -->
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="font-educ" for="editRole<?php echo e($user->id); ?>">Role</label>
                                            <select name="role" id="editRole<?php echo e($user->id); ?>" class="form-control fonts dropdown-role" required>
                                                <?php if(Auth::user()->role == 'Admin'): ?>
                                                    <!-- Admin can view and select all roles -->
                                                    <option value="Admin" <?php echo e($user->role == 'Admin' ? 'selected' : ''); ?>>Admin</option>
                                                    <option value="BUH" <?php echo e($user->role == 'BUH' ? 'selected' : ''); ?>>Business Unit Head</option>
                                                    <option value="Sales_Agent" <?php echo e($user->role == 'Sales_Agent' ? 'selected' : ''); ?>>Sales Agent</option>
                                                    <option value="Head" <?php echo e($user->role == 'Head' ? 'selected' : ''); ?>>Head</option>
                                                    <option value="Sale_Admin" <?php echo e($user->role == 'Sale_Admin' ? 'selected' : ''); ?>>Sale Admin</option>
                                                    <option value="NA" <?php echo e($user->role == 'NA' ? 'selected' : ''); ?>>Not Assigned</option>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <!-- BUH Inputs -->
                                    <div class="col-md-12" id="buhDiv">
                                        <div class="form-group">
                                            <label for="headList" class="font-educ">Head</label>
                                            <select name="headList" id="headList" class="form-control fonts">
                                                <option value="">Select an Option</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="buhCountry" class="font-educ">Country</label>
                                            <select name="buhCountry" id="buhCountry" class="form-control fonts">
                                                <option value="">Select an Option</option>
                                            </select>
                                        </div>
                                    </div>
                                    <!-- Sale Agent Inputs -->
                                    <div class="col-md-12" id="saleAgentDiv">
                                        <div class="form-group">
                                            <label for="selectBUH" class="font-educ">BUH</label>
                                            <select name="selectBUH" id="selectBUH" class="form-control fonts">
                                                <option value="">Select an Option</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="saleAgentCountry" class="font-educ">Country</label>
                                            <select name="saleAgentCountry" id="saleAgentCountry" class="form-control fonts">
                                                <option value="">Select an Option</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer" style="border: none">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn"
                                        style="background: #91264c; color:white;">Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- Delete User Modal -->
        <?php $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="deleteUserModal<?php echo e($user->id); ?>" tabindex="-1"
                aria-labelledby="deleteUserModalLabel<?php echo e($user->id); ?>" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content text-center">
                        <div class="icon-container mx-auto">
                            <i class="fa-solid fa-trash"></i>
                        </div>
                        <div class="modal-header border-0">
                        </div>
                        <div class="modal-body">
                            <p class="">You are about to delete this User List</p>
                            <p class="text-muted">This will delete the user from your list.</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <!-- Update the form action to point to your delete route -->
                            <form action="<?php echo e(route('admin#delete-user', ['id' => $user->id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- Modal for Adding New User -->
        <div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content rounded-0">
                    <div class="modal-header"
                        style="background: linear-gradient(180deg, rgb(255, 180, 206) 0%, hsla(0, 0%, 100%, 1) 100%);
                        border:none;border-top-left-radius: 0; border-top-right-radius: 0;">
                        <h5 class="modal-title" id="addUserModalLabel" style="color: #91264c;">Create New User</h5>
                    </div>
                    <div class="modal-body" style="color: #91264c">
                        <form id="addUserForm" action="<?php echo e(route('admin#save-new-user')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" class="form-control" id="name" name="name"
                                    value="<?php echo e(old('name')); ?>" minlength="3" maxlength="50" required>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" id="email" name="email"
                                    value="<?php echo e(old('email')); ?>" required>
                                <small class="text-danger" id="emailError"></small>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <input type="hidden" class="form-control" id="password" name="password"
                                    value="creatingtestaccount" readonly>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <input type="hidden" class="form-control" id="password_confirmation"
                                    name="password_confirmation" value="creatingtestaccount" readonly>
                            </div>
                            <div class="modal-footer" style="border: none">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary"
                                    style="background: #91264c; color: white;">Create User</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-danger text-center mt-5">
            <strong>Access Denied!</strong> You do not have permission to view this page.
        </div>
    <?php endif; ?>
    <!-- JavaScript for Validation -->
    <script src=" <?php echo e(asset('js/add_agent_validation.js')); ?> "></script>
    <script src=" <?php echo e(asset('js/sort.js')); ?> "></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CMS\Educlaas\hubspot-cms-project\resources\views/User_List_Page.blade.php ENDPATH**/ ?>