<?php

return [
    App\Providers\AppServiceProvider::class,
    \SocialiteProviders\Manager\ServiceProvider::class,
];
