<?php $__env->startSection('title', 'Sale Agent Dashboard'); ?>




<?php $__env->startSection('content'); ?>
    <?php if(Session::has('success')): ?>
        <script type="text/javascript">
            $(document).ready(function() {
                $('#successModal').modal('show');
            });
        </script>
    <?php endif; ?>
    <?php if((Auth::check() && Auth::user()->role == 'BUH') || (Auth::check() && Auth::user()->role == 'Admin' ) || (Auth::check() && Auth::user()->role == 'Head' )): ?>
        <?php if($errors->any() || session('error')): ?>
            <div class="modal fade" id="errorModal" tabindex="-1" aria-labelledby="errorModalLabel" aria-hidden="false">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header"
                            style="background: linear-gradient(180deg, rgb(255, 180, 206) 0%, hsla(0, 0%, 100%, 1) 100%);
                        border:none;border-top-left-radius: 0; border-top-right-radius: 0;">
                            <h5 class="modal-title" id="errorModalLabel" style="color: #91264c"><strong>Error</strong>
                            </h5>
                        </div>
                        <div class="modal-body" style="color: #91264c;border:none;">
                            <?php echo e(session('error')); ?>

                        </div>
                        <div class="modal-footer" style="border:none;">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal"
                                style="background: #91264c; color:white;">OK</button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php if(Session::has('success')): ?>
            <!-- Success Modal -->
            <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content rounded-0">
                        <div class="modal-header"
                            style="background: linear-gradient(180deg, rgb(255, 180, 206) 0%, hsla(0, 0%, 100%, 1) 100%);
                        border:none;border-top-left-radius: 0; border-top-right-radius: 0;">
                            <h5 class="modal-title" id="successModalLabel" style="color: #91264c"><strong>Success</strong>
                            </h5>
                        </div>
                        <div class="modal-body" style="color: #91264c;border:none;">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                        <div class="modal-footer" style="border:none;">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal"
                                style="background: #91264c; color:white;">OK</button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <div class="container-max-height">
            <div class="table-title d-flex justify-content-between align-items-center mb-3">
                <div class="d-flex align-items-center">
                    <h2 style="margin: 0 0.5rem 0 0.25rem;" class="font-educ headings">Sales Agents</h2>
                    <button class="btn hover-action" data-toggle="modal" data-target="#addSalesAgentModal"
                        style="padding: 10px 12px;">
                        <i class="fa-solid fa-square-plus"></i>
                    </button>
                </div>
                <div class="d-flex align-items-center mr-3">
                    <div class="search-box d-flex align-items-center ml-3">
                        <input type="search" class="form-control mr-1" placeholder="Search by Name and Country" id="search-input"
                            aria-label="Search">
                        <button style="padding: 10px 12px;" class="btn hover-action" type="button" data-toggle="tooltip"
                            title="Search">
                            <i class="fa-solid fa-magnifying-glass"></i>
                        </button>
                    </div>
                </div>
            </div>
            <div class="table-container">
                <table id="sales-agents-table" class="table table-hover mt-2">
                    <thead class="font-educ text-left">
                        <tr>
                            <th scope="col">No#</th>
                            <th scope="col" id="name-header">Name
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a" id="sortDown-name"
                                    onclick="sortTable('name', 'asc'); toggleSort('sortDown-name', 'sortUp-name')"></i>
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-up-a-z" id="sortUp-name"
                                    onclick="sortTable('name', 'desc'); toggleSort('sortUp-name', 'sortDown-name')"
                                    style="display: none;"></i>
                            </th>
                            <th scope="col">Hubspot ID</th>
                            <th scope="col" id="country-header">Country
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a" id="sortDown-country"
                                    onclick="sortTable('country', 'asc'); toggleSort('sortDown-country', 'sortUp-country')"></i>
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-up-a-z" id="sortUp-country"
                                    onclick="sortTable('country', 'desc'); toggleSort('sortUp-country', 'sortDown-country')"
                                    style="display: none;"></i>
                            </th>
                            <th scope="col" id="bu-header">BU
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-down-z-a" id="sortDown-bu"
                                    onclick="sortTable('bu', 'asc'); toggleSort('sortDown-bu', 'sortUp-bu')"></i>
                                <i class="ml-2 fa-sharp fa-solid fa-arrow-up-a-z" id="sortUp-bu"
                                    onclick="sortTable('bu', 'desc'); toggleSort('sortUp-bu', 'sortDown-bu')"
                                    style="display: none;"></i>
                            </th>
                            <th scope="col" class="text-center" data-toggle="tooltip" data-placement="top"
                                title="Total contacts in Interested, Archive, and Discard tables">Total Assign Contacts
                            </th>
                            <th scope="col" class="text-center" data-toggle="tooltip" data-placement="top"
                                title="Total contacts synced in HubSpot">Total Hubspot Sync</th>
                            <th scope="col" class="text-center" data-toggle="tooltip" data-placement="top"
                                title="Total engaging contacts">Total In Progress</th>
                            <th class="position-relative" scope="col">
                                Status
                                <i style="cursor: pointer;" class="fa-solid fa-filter" id="filterIcon"
                                    onclick="toggleFilterStatus()"></i>
                                <!-- Filter Container -->
                                <div id="filterStatusContainer" class="filter-popup container rounded-bottom"
                                    style="display: none;">
                                    <div class="row">
                                        <div class="filter-option">
                                            <input class="ml-3" type="checkbox" id="active" name="status"
                                                value="active" onclick="applyStatusFilter()">
                                            <label for="active" style= "color: #006400;">Active</label>
                                        </div>
                                        <div class="filter-option">
                                            <input class="ml-3" type="checkbox" id="inactive" name="status"
                                                value="inactive" onclick="applyStatusFilter()">
                                            <label for="inactive" style="color: #8b0000;">Inactive</label>
                                        </div>
                                    </div>
                                </div>
                            </th>
                            <th scope="col" class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="text-left fonts">
                        <?php $i = ($owner->currentPage() - 1) * $owner->perPage() + 1; ?>
                        <?php $__currentLoopData = $owner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owners): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr data-status="<?php echo e($owners->status); ?>">
                                <td> <?php echo e($i++); ?> </td>
                                <td><?php echo e($owners->name); ?></td>
                                <td><?php echo e($owners->hubspot_id); ?></td>
                                <td>
                                    <?php $countryCodeMapper = app('App\Services\CountryCodeMapper'); ?>
                                    <?php
                                        // Fetch the country code using the injected service
                                        $countryCode = $countryCodeMapper->getCountryCode($owners->nationality);
                                    ?>
                                    <?php if($countryCode): ?>
                                        <img src="<?php echo e(asset('flags/' . strtolower($countryCode) . '.svg')); ?>"
                                            alt="<?php echo e($owners->nationality); ?>" width="20" height="15">
                                    <?php else: ?>
                                        <!-- Optional: Add a fallback image or text when the country code is not found -->
                                        <span>No flag available</span>
                                    <?php endif; ?>
                                    <?php echo e($owners->nationality); ?>

                                </td>
                                <td>
                                    <?php echo e($owners->business_unit); ?>

                                </td>
                                <?php $contactModel = app('App\Models\Contact'); ?>
                                <?php $contactArchiveModel = app('App\Models\ContactArchive'); ?>
                                <?php $contactDiscardModel = app('App\Models\ContactDiscard'); ?>
                                <td class="text-center">
                                    <?php echo e($contactModel->where('fk_contacts__sale_agent_id', $owners->id)->count() +
                                        $contactArchiveModel->where('fk_contacts__sale_agent_id', $owners->id)->count() +
                                        $contactDiscardModel->where('fk_contacts__sale_agent_id', $owners->id)->count()); ?>

                                </td>
                                <td class="text-center"><?php echo e($owners->total_hubspot_sync); ?></td>
                                <td class="text-center"><?php echo e($owners->total_in_progress); ?></td>
                                <td>
                                    <span class="status-indicator"
                                        style="background-color:  
                                            <?php if($owners->status === 'active'): ?> #90ee90; color: #006400;
                                            <?php elseif($owners->status === 'inactive'): ?>#ff7f7f; color: #8b0000; <?php endif; ?>">
                                        <?php if($owners->status === 'active'): ?>
                                            Active
                                        <?php elseif($owners->status === 'inactive'): ?>
                                            Inactive
                                        <?php endif; ?>
                                    </span>
                                </td>
                                <td class="d-flex justify-content-center align-items-center">
                                    
                                    <a href="<?php echo e(Auth::user()->role == 'Admin' ? route('admin#transfer-contact', ['id' => $owners->id]) : route('buh#transfer-contact', $owners->id)); ?>"
                                        class="btn hover-action <?php if(Auth::user()->role == 'Admin'): ?> d-none <?php endif; ?>" style="padding: 10px 12px;">
                                        <i class="fa-solid fa-right-left"></i>
                                    </a>
                                    <a href="<?php echo e(Auth::user()->role == 'Admin' ? route('admin#view-sale-agent', $owners->id) : route('buh#view-sale-agent', $owners->id)); ?>"
                                        class="btn hover-action mx-2" style="padding: 10px 12px;">
                                        <i class="fa-solid fa-eye"></i>
                                    </a>
                                    
                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div aria-label="Page navigation example " class="paginationContainer">
                <ul class="pagination justify-content-center">
                    <!-- Previous Button -->
                    <li class="page-item <?php echo e($owner->onFirstPage() ? 'disabled' : ''); ?>">
                        <a class="page-link font-educ" href="<?php echo e($owner->previousPageUrl()); ?>"
                            aria-label="Previous">&#60;</a>
                    </li>
                    <!-- First Page Button -->
                    <?php if($owner->currentPage() > 3): ?>
                        <li class="page-item">
                            <a class="page-link font-educ" href="<?php echo e($owner->url(1)); ?>">1</a>
                        </li>
                        <li class="page-item">
                            <a class="page-link font-educ" href="<?php echo e($owner->url(2)); ?>">2</a>
                        </li>
                        <li class="page-item disabled">
                            <span class="page-link">...</span>
                        </li>
                    <?php endif; ?>
                    <!-- Middle Page Buttons -->
                    <?php for($i = max($owner->currentPage() - 1, 1); $i <= min($owner->currentPage() + 1, $owner->lastPage()); $i++): ?>
                        <li class="page-item <?php echo e($i == $owner->currentPage() ? 'active' : ''); ?>">
                            <a class="page-link font-educ <?php echo e($i == $owner->currentPage() ? 'active-bg' : ''); ?>"
                                href="<?php echo e($owner->url($i)); ?>"><?php echo e($i); ?></a>
                        </li>
                    <?php endfor; ?>
                    <!-- Last Page Button -->
                    <?php if($owner->currentPage() < $owner->lastPage() - 2): ?>
                        <li class="page-item disabled">
                            <span class="page-link">...</span>
                        </li>
                        <li class="page-item">
                            <a class="page-link font-educ"
                                href="<?php echo e($owner->url($owner->lastPage() - 1)); ?>"><?php echo e($owner->lastPage() - 1); ?></a>
                        </li>
                        <li class="page-item">
                            <a class="page-link font-educ"
                                href="<?php echo e($owner->url($owner->lastPage())); ?>"><?php echo e($owner->lastPage()); ?></a>
                        </li>
                    <?php endif; ?>
                    <!-- Next Button -->
                    <li class="page-item <?php echo e(!$owner->hasMorePages() ? 'disabled' : ''); ?>">
                        <a class="page-link font-educ" href="<?php echo e($owner->nextPageUrl()); ?>" aria-label="Next">&#62;</a>
                    </li>
                </ul>
            </div>
        </div>
        </div>
        <?php $__currentLoopData = $owner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owners): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="deleteOwnerModal<?php echo e($owners->id); ?>" tabindex="-1"
                aria-labelledby="deleteOwnerModalLabel<?php echo e($owners->id); ?>" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content text-center">
                        <div class="icon-container mx-auto">
                            <i class="fa-solid fa-trash"></i>
                        </div>
                        <div class="modal-header border-0">
                        </div>
                        <div class="modal-body">
                            <p>You are about to delete this Sales Agent</p>
                            <p class="text-muted">This will delete your sales agent from your list.</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <form action="<?php echo e(route('buh#delete-sale-agent', $owners->id)); ?>" method="post">
                                
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="alert alert-danger text-center mt-5">
            <strong>Access Denied!</strong> You do not have permission to view this page.
        </div>
    <?php endif; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src=" <?php echo e(asset('js/filter_status.js')); ?> "></script>
    <script src=" <?php echo e(asset('js/agent_form_handler.js')); ?> "></script>
    <script src=" <?php echo e(asset('js/sort.js')); ?> "></script>
    <script src=" <?php echo e(asset('js/search_input.js')); ?>" ></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Add_Sales-Agent_Modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CMS\Educlaas\hubspot-cms-project\resources\views/Sale_Agent_Page.blade.php ENDPATH**/ ?>