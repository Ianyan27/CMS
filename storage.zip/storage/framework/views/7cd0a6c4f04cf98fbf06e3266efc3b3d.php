<!-- Edit Contact Modal -->
<div class="modal fade" id="editContactModal" tabindex="-1" aria-labelledby="editContactModalLabel"
aria-hidden="true">
<div class="modal-dialog modal-lg">
    <div class="modal-content rounded-0">
        <div class="modal-header d-flex justify-content-between align-items-center"
        style="background: linear-gradient(180deg, rgb(255, 180, 206) 0%, hsla(0, 0%, 100%, 1) 100%);
            border:none;border-top-left-radius: 0; border-top-right-radius: 0;">
            <h5 class="modal-title" id="editContactModalLabel">
                <strong>Edit Contact</strong>
            </h5>
            <!-- Adding the logo on the right side -->
            <img src="<?php echo e(url('/images/02-EduCLaaS-Logo-Raspberry-300x94.png')); ?>" alt="Company Logo"
                style="height: 30px;">
        </div>
        <div class="modal-body">
            <form action="<?php echo e(Auth::user()->role == 'Admin' ? route('admin#update-contact', ['contact_pid' => $editContact->contact_pid, 'id' => $user->id]) : route('contact#update-contact',['contact_pid' => $editContact->contact_pid, 'owner_pid' => $owner->owner_pid])); ?>" 
                
                method="POST" id="editContactForm">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <!-- Left Column -->
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="font-educ" for="contact-name">Name</label>
                            <input type="text" class="form-control fonts" id="name" name="name"
                                value="<?php echo e($editContact->name); ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="font-educ" for="contact-email">Email</label>
                            <input type="email" class="form-control fonts" id="email" name="email"
                                value="<?php echo e($editContact->email); ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="font-educ" for="contact-country">Country</label>
                            <input type="text" class="form-control fonts" id="contact-country" name="country"
                                value="<?php echo e($editContact->country); ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="font-educ" for="contact-address">Address</label>
                            <input class="form-control fonts" style="height: 103px;" type="text" name="address"
                                id="address" value="<?php echo e($editContact->address); ?>">
                        </div>
                    </div>
                    <!-- Middle Column -->
                    <div class="col-md-4">
                        <div class="form-group">
                            <div class="d-flex justify-content-between align-items-center">
                                <label class="font-educ" for="contact-number">Contact Number</label>
                            </div>
                            <div>
                                <input type="text" class="form-control fonts" id="contact-number"
                                    name="contact_number" value="<?php echo e($editContact->contact_number); ?>" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="d-flex justify-content-between align-items-center">
                                <label class="font-educ" for="contact-qualification">Qualification</label>
                            </div>
                            <div>
                                <input type="text" class="form-control fonts" id="contact-qualification"
                                    value="<?php echo e($editContact->qualification); ?>" name="qualification" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="font-educ" for="contact-role">Job Role</label>
                            <input type="text" class="form-control fonts" name="job_role" id="contact-role"
                                value="<?php echo e($editContact->job_role); ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="font-educ" for="contact-skills">Skills</label>
                            <input type="text" class="form-control fonts" name="skills" id="contact-skills"
                                value="<?php echo e($editContact->skills); ?>" required>
                        </div>
                    </div>
                    <!-- Right Column -->
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="font-educ" for="contact-allocation">Date of Allocation</label>
                            <input type="datetime" class="form-control fonts" id="contact-allocation"
                                value="<?php echo e($editContact->date_of_allocation); ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label class="font-educ" for="contact-source">Source</label>
                            <input type="text" class="form-control fonts" id="contact-source"
                                value="<?php echo e($editContact->source); ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label class="font-educ" for="contact-status">Status</label>
                            <select class="form-control fonts" id="contact-status" name="status" required>
                                <option value="InProgress" <?php echo e($editContact->status === 'InProgress' ? 'selected' : ''); ?>>
                                    In Progress
                                </option>
                                <option value="HubSpot Contact" <?php echo e($editContact->status === 'HubSpot Contact' ? 'selected' : ''); ?>>
                                    HubSpot
                                </option>
                                <option value="Discard" <?php echo e($editContact->status === 'discard' ? 'selected' : ''); ?>>
                                    Discard
                                </option>
                                <option value="New" <?php echo e($editContact->status === 'New' ? 'selected' : ''); ?>>
                                    New
                                </option>
                                <option value="Archive" <?php echo e($editContact->status === 'Archive' ? 'selected' : ''); ?>>
                                    Archive
                                </option>
                            </select>
                            <?php if($errors->has('status')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('status')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn " style="background: #91264c; color:white;">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
</div><?php /**PATH D:\CMS\Educlaas\hubspot-cms-project\resources\views/layouts/Edit_Contact_Modal.blade.php ENDPATH**/ ?>